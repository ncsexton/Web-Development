###################################################################
#            Omeka-S Installation Script Instructions             #
###################################################################

It is recommended that this script be used on a fresh Linux install.
If running on an already installed OS, you may have conflicting 
versions of software that Omeka, and this script, use. A new VM
instance should offer the best results!

The install script located within this archive will assist you in 
getting an install of Omeka-S up and running on a Linux system.

It has been tested on Ubuntu 20.04.3 LTS.

Download Omeka-S from https://omeka.org/s/download

Extract that zip file within your /var/www/html directory, to provide 
access to the web. Once that file has been extracted, extract the
install.tar.gz inside your Omeka-S directory and simply run 
install.sh from the resulting directory to install/check for dependencies. 

If the necessary software is already installed, it will be skipped.

Omeka-S requires its own database to operate, IT IS HIGHLY RECOMMENDED
THAT YOU CREATE A NEW DATABASE USING THE INSTALL SCRIPT!!! If you choose
to NOT use the install script to create a new database, you will be
responsible for setting up the omeka-s/config/database.ini file on your
own.

