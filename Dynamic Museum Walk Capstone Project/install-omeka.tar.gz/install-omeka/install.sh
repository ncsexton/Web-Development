#!/bin/bash
dbName=""
dbPass=""
dbUser="root"
rootPass=""

function begin_setup() {
  echo -e "\nUpdating packages...\n"
  update_packages

  echo -e "\nChecking for Apache2 installation...\n"
  apache_check

  echo -e "\nChecking for MySQL installation...\n"
  mysql_check

  echo -e "\nChecking for PHP installation...\n"
  php_check

  echo -e "\nChecking for Image Magick installation...\n"
  imagick_check
}
function update_packages() {
  sudo apt update -qq
  return
}
function apache_check() {
  if [[ ! $(dpkg-query -W -f='${Status}' apache2 | grep "ok installed") ]]
  then
    sudo apt-get install apache2 -yqq
    sudo service apache2 start
  else
    echo "Apache2 already installed..."
  fi
  return 
}
function mysql_check() {
  if [[ ! $(dpkg-query -W -f='${Status}' mysql-server | grep "ok installed") ]]
  then
    sudo apt-get install mysql-server -yqq
    sudo service mysql start
  else
    echo "MySQL-Server already installed..."
  fi
  sudo mysql -e "ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'admin1234';"
  sudo mysql -e "FLUSH PRIVILEGES;"
  return
}
function php_check() {
  if [[ ! $(dpkg-query -W -f='${Status}' php7.4 | grep "ok installed") ]]
  then
    sudo apt-get install software-properties-common -yqq
    sudo add-apt-repository ppa:ondrej/php -y
    sudo apt-get install php7.4 libapache2-mod-php7.4 -yqq
    sudo apt-get install php7.4-mbstring
    sudo apt-get install php7.4-xml
  else
    echo "PHP7.4 already installed..."
  fi

  if [[ ! $(dpkg-query -W -f='${Status}' php7.4-mysql | grep "ok installed") ]]
  then
    sudo apt-get install php7.4-mysql -yqq
    sudo phpenmod pdo_mysql
  else
    echo "PHP7.4-MySQL already installed..."
  fi
  return
}
function imagick_check() {
  if [[ ! $(dpkg-query -W -f='${Status}' php-imagick | grep "ok installed") ]]
  then
    sudo apt-get install php-imagick -yqq
  else
    echo "Image Magick already installed..."
  fi
  return
}
function create_db() {
  read -p "Enter database name: " dbName
  read -p "Is ${dbName} correct? Y/N: " confirm

  while [[ $confirm != 'y' && $confirm != 'Y' ]]
  do
    read -p "Enter database name: " dbName
    read -p "Is ${dbName} correct? Y/N: " confirm
  done

  read -p "Use root for user? Y/N: " useRoot
  if [[ $useRoot = 'n' || $useRoot = 'N' ]]
  then
    read -p "Enter username: " dbUser
    read -p "Is ${dbUser} correct? Y/N: " confirm

    while [[ $confirm != 'y' && $confirm != 'Y' ]]
    do
      read -p "Enter username: " dbUser
      read -p "Is ${dbUser} correct? Y/N: " confirm
    done

    read -sp "Enter password (note password will not be visible): " dbPass
    echo -e "\n"
    read -sp "Confirm password: " confirmPass

    while [[ $confirmPass != $dbPass ]]
    do
      echo -e "\nPassword did not match, try again\n"
      read -sp "Enter password (note password will not be visible): " dbPass
      echo -e "\n"
      read -sp "Confirm password: " confirmPass
    done
  else
    echo -e "\nIf this is the first time using MySQL on this system, default root password has been set to 'admin1234'\n"
    read -sp "Enter root password (note password will not be visible): " rootPass
  fi

  if [[ -f /root/.my.cnf ]]
  then
    mysql -e "CREATE DATABASE IF NOT EXISTS ${dbName} DEFAULT CHARACTER SET utf8;"
    mysql -e "CREATE USER ${dbUser}@localhost IDENTIFIED BY '${dbPass}';"
    mysql -e "GRANT ALL PRIVILEGES ON ${dbName}.* TO '${dbUser}'@'localhost';"
    mysql -e "FLUSH PRIVILEGES;"
  else
    echo -e "\n/root/.my.cnf file not found. Root login required."
    echo -e "\nIf this is the first time using MySQL on this system, default root password has been set to 'admin1234'\n"
    read -sp "Enter root password (note password will not be visible): " rootPass
    mysql -uroot -p${rootPass} -e "CREATE DATABASE IF NOT EXISTS ${dbName} DEFAULT CHARACTER SET utf8;"
    mysql -uroot -p${rootPass} -e "CREATE USER ${dbUser}@localhost IDENTIFIED BY '${dbPass}';"
    mysql -uroot -p${rootPass} -e "GRANT ALL PRIVILEGES ON ${dbName}.* TO '${dbUser}'@'localhost';"
    mysql -uroot -p${rootPass} -e "FLUSH PRIVILEGES;"
  fi
  return
}
function create_db_config() {
  truncate -s 0 ../config/database.ini
  echo "user     = \"${dbUser}\"" >> ../config/database.ini
  echo "password = \"${dbPass}\"" >> ../config/database.ini
  echo "dbname   = \"${dbName}\"" >> ../config/database.ini
  echo "host     = \"\"         " >> ../config/database.ini
  echo ";port    =              " >> ../config/database.ini
  echo ";unix_socket =          " >> ../config/database.ini
  echo "log_path =              " >> ../config/database.ini
  return
}
echo -e "\n"
echo -e "============================================================================"
echo -e "= This script will guide you through the Omeka-S install and setup process ="
echo -e "=     This script should be in your Omeka-S directory. If not enter 'N'    =" 
echo -e "============================================================================"
echo -e "\n"

read -p "Has the Omeka-S zip file been downloaded and unzipped, Y/N?: " zipPrompt

if [[ $zipPrompt = 'N' || $zipPrompt = 'n' ]] 
then
  echo -e "Please download and unzip Omeka-S and retry"
  exit
elif [[ $zipPrompt = 'Y' || $zipPrompt = 'y' ]]
then
  begin_setup
  #echo "Skipping install"
fi

echo -e "\n"
read -p "Would you like to create a new database? (Omeka requires its own database) Y/N: " dbPrompt

if [[ $dbPrompt = 'Y' || $dbPrompt = 'y' ]]
then
  create_db
  create_db_config
fi

sudo a2enmod rewrite
sudo a2enmod php7.4
sudo service apache2 restart

sudo chmod -R 777 .
sudo chown -R ${USER}:${USER} .
sudo cp apache2.conf /etc/apache2/apache2.conf
sudo service apache2 restart

basename=$(basename "$(dirname $PWD)")
xdg-open http://127.0.0.1/${basename}/install
